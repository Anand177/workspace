/**
 * 
 */
/**
 * @author training
 *
 */
package simpleWordCount;